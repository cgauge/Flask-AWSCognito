class FlaskAWSCognitoError(Exception):
    pass


class TokenVerifyError(Exception):
    pass
